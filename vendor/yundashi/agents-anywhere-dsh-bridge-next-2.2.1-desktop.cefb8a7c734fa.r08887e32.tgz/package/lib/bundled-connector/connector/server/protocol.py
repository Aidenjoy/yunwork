from __future__ import annotations

import base64
import hashlib
import json
from typing import Any, Literal

from pydantic import BaseModel, Field

PROTOCOL_VERSION_1 = "1.0"
SUPPORTED_PROTOCOL_VERSIONS = ["1.1", PROTOCOL_VERSION_1]
PROTOCOL_MAX_REVISION = 9_007_199_254_740_991

ProtocolVersion = Literal["1.0", "1.1"]
RuntimeName = str
ProtocolCapabilityScope = Literal["runtime", "session"]
ProtocolNoticeType = Literal["notification", "interaction"]
ProtocolNoticeSeverity = Literal["info", "success", "warning", "error"]
ProtocolInteractionStatus = Literal[
    "open",
    "responding",
    "response_accepted",
    "resolving",
    "resolved",
    "expired",
    "cancelled",
    "failed",
]
ProtocolActionStyle = Literal["primary", "secondary", "danger", "default"]


class RpcRequest(BaseModel):
    id: str
    type: Literal["request"] = "request"
    method: str
    params: Any = None


class RpcResponse(BaseModel):
    id: str
    type: Literal["response"] = "response"
    ok: bool
    result: Any = None
    error: dict[str, str] | None = None


class RpcNotification(BaseModel):
    type: Literal["notification"] = "notification"
    method: str
    params: Any = None


class ProtocolRuntimeIdentity(BaseModel):
    runtime: RuntimeName
    runtimeVersion: str


class ProtocolHandshakeRequest(BaseModel):
    protocolVersions: list[str] = Field(min_length=1)
    connectorVersion: str
    runtimes: list[ProtocolRuntimeIdentity] = Field(default_factory=list)


class ProtocolCapability(BaseModel):
    capabilityId: str
    version: str = "1"
    scope: ProtocolCapabilityScope = "runtime"
    runtime: RuntimeName | None = None
    sessionId: str | None = None
    supported: bool = True
    available: bool = True
    allowed: bool = True
    unavailableReason: str | None = None
    parameters: dict[str, Any] = Field(default_factory=dict)


class ProtocolCapabilitySet(BaseModel):
    revision: int = Field(ge=0, le=PROTOCOL_MAX_REVISION)
    capabilities: list[ProtocolCapability] = Field(default_factory=list)


class ProtocolReasoningItem(BaseModel):
    displayName: str
    id: str
    fullModelId: str | None = None
    selectionId: str
    description: str | None = None
    default: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)


class ProtocolModelGroup(BaseModel):
    id: str = Field(min_length=1)
    displayName: str = Field(min_length=1)
    itemDisplayName: str | None = Field(default=None, min_length=1)


class ProtocolModelItem(BaseModel):
    displayName: str
    id: str
    selectionId: str | None = None
    description: str | None = None
    default: bool = False
    reasoningItems: list[ProtocolReasoningItem] = Field(default_factory=list)
    group: ProtocolModelGroup | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ProtocolModelCatalog(BaseModel):
    runtime: RuntimeName
    revision: int = Field(ge=0, le=PROTOCOL_MAX_REVISION)
    models: list[ProtocolModelItem] = Field(default_factory=list)


class ProtocolPermissionItem(BaseModel):
    displayName: str
    id: str
    selectionId: str
    description: str | None = None
    default: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)


class ProtocolPermissionCatalog(BaseModel):
    runtime: RuntimeName
    revision: int = Field(ge=0, le=PROTOCOL_MAX_REVISION)
    permissions: list[ProtocolPermissionItem] = Field(default_factory=list)


class ProtocolNoticeSource(BaseModel):
    runtime: RuntimeName
    component: str | None = None
    approvalId: str | None = None
    timelineItemId: str | None = None
    operationId: str | None = None


class ProtocolNoticeBlocking(BaseModel):
    scope: Literal["session", "tool_call", "runtime"]
    targetId: str


class ProtocolNoticeActionInput(BaseModel):
    required: bool = False
    schema_: dict[str, Any] | None = Field(default=None, alias="schema")
    uiSchema: dict[str, Any] | None = None


class ProtocolNoticeAction(BaseModel):
    actionId: str
    label: str
    style: ProtocolActionStyle = "default"
    input: ProtocolNoticeActionInput = Field(default_factory=ProtocolNoticeActionInput)


class ProtocolNotice(BaseModel):
    noticeId: str
    type: ProtocolNoticeType
    sessionId: str | None = None
    source: ProtocolNoticeSource
    title: str
    message: str | None = None
    severity: ProtocolNoticeSeverity = "info"
    createdAt: str | None = None
    expiresAt: str | None = None
    revision: int = Field(default=1, ge=1)
    metadata: dict[str, Any] = Field(default_factory=dict)
    interactionType: str | None = None
    status: ProtocolInteractionStatus | None = None
    blocking: ProtocolNoticeBlocking | None = None
    responseRequired: bool = False
    actions: list[ProtocolNoticeAction] = Field(default_factory=list)
    context: dict[str, Any] = Field(default_factory=dict)


def protocol_selection_id(runtime: str, catalog_type: str, identity: dict[str, Any]) -> str:
    canonical_identity = json.dumps(identity, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    raw = f"1:{runtime}:{catalog_type}:{canonical_identity}".encode()
    digest = base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).decode().rstrip("=")
    return f"sel_{catalog_type}_{digest[:24]}"
