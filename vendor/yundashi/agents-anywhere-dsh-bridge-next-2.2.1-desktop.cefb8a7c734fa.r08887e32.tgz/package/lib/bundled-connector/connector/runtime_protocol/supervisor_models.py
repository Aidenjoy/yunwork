from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import Any

from connector.runtime_protocol.instance_models import (
    RuntimeInstanceLifecycleStatus,
    RuntimeInstanceSpec,
    RuntimeResourceClaim,
)
from connector.runtime_protocol.models import RuntimeConfig
from connector.runtime_protocol.protocol import AgentRuntime
from connector.runtime_protocol.provider import RuntimeProvider

RuntimeLifecycleStatus = RuntimeInstanceLifecycleStatus

RuntimeStatusSink = Callable[
    [str, RuntimeLifecycleStatus, Mapping[str, Any] | None, Mapping[str, Any] | None],
    Awaitable[None],
]


class Missing:
    pass


MISSING = Missing()


@dataclass(frozen=True, slots=True)
class RuntimeSupervisorEntry:
    instance: RuntimeInstanceSpec
    provider: RuntimeProvider
    runtime: AgentRuntime | None = None
    config: RuntimeConfig | None = None
    requested_values: Mapping[str, Any] | None = None
    resource_claims: tuple[RuntimeResourceClaim, ...] = ()
    status: RuntimeLifecycleStatus = "stopped"
    error: Mapping[str, Any] | None = None
    # Finer-grained step of ``status`` (e.g. ``syncing`` while ``starting``).
    phase: Mapping[str, Any] | None = None

    @property
    def runtime_id(self) -> str:
        return self.instance.runtime_id

    @property
    def runtime_type(self) -> str:
        return self.instance.runtime_type

    @property
    def name(self) -> str:
        return self.instance.name


def error_payload(exc: BaseException) -> dict[str, Any]:
    return {
        "code": getattr(exc, "code", None) or exc.__class__.__name__,
        "message": str(exc) or exc.__class__.__name__,
        "retryable": bool(getattr(exc, "retryable", False)),
    }


def only_model_setting_changed(left: RuntimeConfig | None, right: RuntimeConfig) -> bool:
    """Whether the configs differ only in the ``model`` setting new sessions use."""
    if left is None or left.runtime != right.runtime:
        return False
    before, after = dict(left.values), dict(right.values)
    if before.get("model") == after.get("model"):
        return False
    before.pop("model", None)
    after.pop("model", None)
    return before == after


def same_effective_config(left: RuntimeConfig | None, right: RuntimeConfig) -> bool:
    if left is None:
        return False
    return left.runtime == right.runtime and dict(left.values) == dict(right.values)
